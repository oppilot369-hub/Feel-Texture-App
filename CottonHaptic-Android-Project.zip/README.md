# 🪡 Cotton Texture Haptic Viewer - Android App

This project packages your Cotton Texture Haptic Viewer into a native Android app with full hardware vibration support (`android.permission.VIBRATE`).

## 📦 What's included:
1. **Native Jetpack Compose Mode** (`MainActivity.kt`): Uses Android's `VibratorManager` to emit true 10ms micro-haptic ticks when scrolling across the cotton threads.
2. **WebView Mode** (`WebViewActivity.kt`): Runs your exact `index.html` from `assets/index.html` with JavaScript and `navigator.vibrate(10)` enabled!
3. **Automated Cloud APK Build** (`.github/workflows/build-apk.yml`): Pushing to GitHub gives you an APK artifact automatically.

## 🛠️ How to Compile your APK:

### Method 1: Android Studio (Easiest)
1. Open [Android Studio](https://developer.android.com/studio).
2. Click **Open** and select this unzipped folder.
3. In the top menu, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Locate your APK at: `app/build/outputs/apk/debug/app-debug.apk`.
5. Send it to your phone and install!

### Method 2: Command Line (Linux / Mac / Windows)
```bash
# Build APK directly
./gradlew assembleDebug

# Output APK path:
# app/build/outputs/apk/debug/app-debug.apk

# If your Android phone is plugged in via USB (USB debugging on):
./gradlew installDebug
```

### Method 3: GitHub Actions (No Local Setup Required)
1. Push this folder to a GitHub repository.
2. Go to the **Actions** tab.
3. The workflow will automatically compile and produce your downloadable `.apk`!
